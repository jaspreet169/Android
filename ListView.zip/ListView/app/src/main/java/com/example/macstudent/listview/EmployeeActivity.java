package com.example.macstudent.listview;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.macstudent.listview.model.Employee;

import java.util.ArrayList;

public class EmployeeActivity extends Activity {

    ListView lst;
    ArrayList<Employee>EmployeeArrayList;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);


        initialDat();





    }

    public void initialDat() {
        EmployeeArrayList = new ArrayList<>();
        EmployeeArrayList.add(new Employee(1,"jaspreet"));
        EmployeeArrayList.add(new Employee(2,"dhruvi"));
        EmployeeArrayList.add(new Employee(3,"payal"));
        EmployeeArrayList.add(new Employee(4,"navjot"));
        EmployeeArrayList.add(new Employee(5,"inder"));
    }




}
