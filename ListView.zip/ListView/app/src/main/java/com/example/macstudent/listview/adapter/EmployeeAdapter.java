package com.example.macstudent.listview.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;

import com.example.macstudent.listview.R;
import com.example.macstudent.listview.model.Employee;

import java.util.ArrayList;

/**
 * Created by macstudent on 2017-11-28.
 */

public class EmployeeAdapter extends ArrayAdapter<Employee>
{
    public EmployeeAdapter(Context context, ArrayList<Employee> employeeArrayList) {
        super(context, 0, employeeArrayList);

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
         Employee employee  = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_employee, parent, false);
            }
            // Lookup view for data population
            TextView tvempId = (TextView) convertView.findViewById(R.id.txtempId);
            TextView tvempName = (TextView) convertView.findViewById(R.id.txtempName);
            // Populate the data into the template view using the data object
            tvempId.setText(String.valueOf(employee.getEmpId());
            tvempName.setText(employee.getEmpName());
            // Return the completed view to render on screen
            return convertView;
        }
    }

}
