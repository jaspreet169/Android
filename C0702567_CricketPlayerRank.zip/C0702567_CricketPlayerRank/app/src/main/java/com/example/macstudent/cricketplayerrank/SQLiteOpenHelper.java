package com.example.macstudent.cricketplayerrank;

/**
 * Created by macstudent on 2017-12-01.
 */

class SQLiteOpenHelper {
}
